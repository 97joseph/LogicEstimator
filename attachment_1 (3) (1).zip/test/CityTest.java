import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CityTest {

  @Test
  void find() {
  }

  @Test
  void addLink() {
  }

  @Test
  void compareTo() {
  }

  @Test
  void testToString() {
  }

  @Test
  void compare() {
  }

  @Test
  void getLinksTo() {
  }
}